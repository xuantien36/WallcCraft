package com.t3h.wallccraft;

public class EvenPost {
    private int id;
//    private String name;

    public EvenPost(int id) {
        this.id = id;
//        this.name=name;
    }
    public int getId() {
        return id;
    }

//    public String getName() {
//        return name;
    }


